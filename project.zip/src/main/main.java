package main;

import user.UserDAO;

public class main {
	public static void main(String[] args) {
		System.out.println("프로그램 시작");	
		UserDAO user_dao = new UserDAO();
		user_dao.login_state();
	}
	
}
